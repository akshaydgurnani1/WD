// ExampleTemplate.js
import React from "react";

const ExampleTemplate = ({ templateName }) => {
  return (
    <div className="example-template">
      <h2>{templateName}</h2>
      {/* Add template content here */}
    </div>
  );
};

export default ExampleTemplate;
