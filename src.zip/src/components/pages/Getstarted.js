// GetStarted.js
import React, { useState } from "react";
import UsernameInput from "./Username";
import TemplateSelection from "./TemplateSelection";
import "./GetStarted.css";

const GetStarted = () => {
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [username, setUsername] = useState("");
  const [showUsernameInput, setShowUsernameInput] = useState(true);

  const templates = [
    { id: 1, name: "Template 1" },
    { id: 2, name: "Template 2" },
    {id: 3, name: "Template 3"}
  ];

  const handleUsernameSubmitted = () => {
    setShowUsernameInput(false);
  };

  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
  };

  return (
    <div className="get-started-container bg-blue-100 rounded-xl">
      <h1 className="header ">Get Started</h1>
      {showUsernameInput ? (
        <UsernameInput onSetUsername={setUsername} onUsernameSubmitted={handleUsernameSubmitted} />
      ) : (
        <TemplateSelection templates={templates} onSelectTemplate={handleSelectTemplate} username={username} />
      )}
    </div>
  );
};

export default GetStarted;
