// UsernameInput.js
import React, { useState } from "react";

const UsernameInput = ({ onSetUsername, onUsernameSubmitted }) => {
  const [username, setUsername] = useState("");

  const handleUsernameSubmit = () => {
    onSetUsername(username);
    onUsernameSubmitted();
  };

  return (
    <div className="flex justify-center ">

    <div className="username-input card-lg m-10 bg-blue-300 p-10 rounded-lg w-1/3 ">
      <div className="w-2/3 flex-col justify-center ml-12">
      <h2 className="text-xl text-left">Enter your Username</h2>

      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        />
      <button  onClick={handleUsernameSubmit} c>Submit</button>
        </div>
    </div>
        </div>
  );
};

export default UsernameInput;
